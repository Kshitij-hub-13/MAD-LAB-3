abstract class Pandavs extends Bharatvanshi
{
    void obey()
    {
        System.out.println("Pandavs were obedient");
    }
    abstract void kind();
}