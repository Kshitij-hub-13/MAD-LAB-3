abstract class Kauravs extends Bharatvanshi
{
    void Kauravshistory()
    {
        System.out.println("Kauravs were 100 in mumbers");
    }
}