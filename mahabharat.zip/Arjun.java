class Arjun extends Pandavs
{
    void kind()
    {
        System.out.println("Arjun was kind");
    }
}