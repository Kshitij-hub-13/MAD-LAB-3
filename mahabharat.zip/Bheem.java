class Bheem extends Pandavs
{
    void kind()
    {
        System.out.println("Bheem was less kind than Arjun");
    }
}